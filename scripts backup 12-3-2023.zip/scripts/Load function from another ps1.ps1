﻿Import-Module -Name '\\fs\Shares\Engineering\ADC\QA\PS\scripts\get-crc32.ps1' #loading function from another .ps1
Get-Command Get-CRC32