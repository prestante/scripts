﻿[xml]$xml = '
<wtf> 
    <ID>
        21526
    </ID>
    <Command>
        set item batch
    </Command>
    <Parameters>
        <Names>
            <Layout>
                ForUpdateText
            </Layout>
            <Item>
                Title
            </Item>
        </Names>
        <Item>
            <Properties>
                <TextUpdate>
                    <Tag>
                        <Name>
                            Field1
                        </Name>
                        <Text>
                            <![CDATA[
                            <Program2>
                            ]]>
                        </Text>
                    </Tag>
                </TextUpdate>
            </Properties>
        </Item>
        <Names>
            <Layout>
                ForUpdateText
            </Layout>
            <Item>
                Title1
            </Item>
        </Names>
        <Item>
            <Properties>
                <TextUpdate>
                    <Tag>
                        <Name>
                            Field1
                        </Name>
                        <Text>
                            <![CDATA[
                            <Program3>
                            ]]>
                        </Text>
                    </Tag>
                </TextUpdate>
            </Properties>
        </Item>
    </Parameters>
</wtf>
'




