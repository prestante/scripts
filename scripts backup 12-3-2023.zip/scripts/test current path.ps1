﻿$scriptPath = split-path -parent $MyInvocation.MyCommand.Definition
$scriptPath 
Read-Host